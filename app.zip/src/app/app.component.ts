import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PeopleManagementService } from './services/people-management.service';
import { createUrlResolverWithoutPackagePrefix } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit {
  // #region variable
  title = 'randomNames';
  people: any;
  choosenPerson: any = null;
  numbers: number[] = [1,2,3,4,5,6,7,8,9,10];

  /**Deve essere dello stesso tipo dell'oggetto iterato nella option! Guardare -> 
  https://stackblitz.com/edit/angular-gh2rjx?file=app%2Fapp.component.html */
  selectedPerson: string = '';
  selectedNumber: number = 2; 

  @ViewChild('choosenPersonDialog') choosenPersonDialog:any;
  //#endregion variable 

  constructor(
    private http_service: HttpClient, 
    private people_management_service: PeopleManagementService) {
    const people = this.getPeople();

  }

  ngAfterViewInit(): void {
    
  }

  /**Ottengo le persone dal file people.json */
  getPeople() {
    const environment = this.getEnvironment(); 
    const asset = environment + '/assets/people/people.json'
    const promise = this.http_service.get((asset));
    promise.toPromise()
      .then((people) => {
        this.people = people;
        console.log(people)
      })
      .catch((error) => {
        console.log(error)
      });
  }

  getClickedNumber() {

  }

  /**Metodo che ritorna dove l'app è attualmente eseguita */
  getEnvironment(): string {
    let env = ''; 
    const url = window.location.href; 
    const u = url.split('://');
    env = u[1];
    return 'http://' + env; 
  }

  /**Metodo che recupera il nome selezionato dalla drop down list */
  getClickedPerson() {
    const person: any = this.getPersonByString(this.selectedPerson)
    this.showSelectedPerson(person);
  }

  /**Metodo che mostra la persona selezionata dall'algoritmo */
  private showSelectedPerson(person: any) {
    const hasPersonBeenChoosen: boolean = person.hasPersonBeenChoosen;
    const choosenPerson = { person: person, hasPersonBeenChoosen: hasPersonBeenChoosen };
    this.choosenPerson = choosenPerson;
    if (hasPersonBeenChoosen) {
      setTimeout(() => {
        this.choosenPersonDialog.nativeElement.innerHTML = null;
      }, 10000);
    }
  }

  /**Metodo che restituisce true o false in base ad un algoritmo del tutto causale */
  isPersonChoosen(person: any): boolean {
    const origin: number = new Date().getTime();
    const userDate: number = this.setPersonDate(person.date).getTime();
    const userDay: Date = this.setPersonDate(person.date);
    const userDayAsTimestamp = userDay.getDate();;
    const diff = Math.abs(origin - userDate); // Data di adesso -  quella dell'utente
    const resto: number = diff % userDay.getDate();
    const isPari = resto === Number(this.selectedNumber);
    return isPari; 
  }

  /**Metodo che esegue ripetutamente i conti fino a quando una persona non verrà per forza atratta a sorte */
  roulette() {
    let hasPersonBeenChoosen: boolean = false; 
    while(!hasPersonBeenChoosen) {
      for (let index = 0; index < this.people.length; index++) {
        const element = this.people[index];
        hasPersonBeenChoosen =  this.isPersonChoosen(element);
        if (hasPersonBeenChoosen) {
          let person = element;
          person.hasPersonBeenChoosen = true;
          this.showSelectedPerson(person);
          break; 
        }
      }
    }
  }

  /**Metodo che permette di settare la data di nascita dell'utene dell'utente */
  setPersonDate(date: any): Date {
    let birthDate: Date = new Date();
    const tokens: Array<any> = date.split('/');
    birthDate.setFullYear(tokens[2], Number(tokens[1]) -1, tokens[0]);
    return birthDate;
  }

  /**Metodo per ottenere i dati della persona selezionata */
  getPersonByString(selectedPerson: any): any {
    let personData = null;
    for (let index = 0; index < this.people.length; index++) {
      const element = this.people[index];
      if (element.name === selectedPerson) {
        personData = element;
      }  
    }
    return personData;
  }
}
