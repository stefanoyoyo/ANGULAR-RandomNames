import { Component, Input, OnInit } from '@angular/core';
import { PeopleManagementService } from '../services/people-management.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
  @Input() choosenPerson: any;

  constructor(private people_management_service: PeopleManagementService) { 
  }

  ngOnInit(): void {
  }

}
